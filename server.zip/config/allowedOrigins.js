const allowedOrigins = [
      "http://localhost:3500",
      "http://localhost:5173",
      process.env.USER_FRONTEND
];

module.exports=allowedOrigins